/*
  # Add unique constraint to device_id

  1. Changes
    - Add unique constraint to `device_id` column in `user_profiles` table
    - Add NOT NULL constraint to ensure device_id is always set
    - Add migration safety by:
      - First removing any duplicate device_ids
      - Then adding the constraints

  2. Purpose
    - Prevent multiple users from having the same device_id
    - Ensure device_id is always set for proper user identification
*/

-- First, handle any existing duplicate device_ids by keeping only the most recently active user
WITH duplicates AS (
  SELECT device_id
  FROM user_profiles
  WHERE device_id IS NOT NULL
  GROUP BY device_id
  HAVING COUNT(*) > 1
),
ranked_users AS (
  SELECT 
    id,
    device_id,
    ROW_NUMBER() OVER (PARTITION BY device_id ORDER BY last_seen DESC) as rn
  FROM user_profiles
  WHERE device_id IN (SELECT device_id FROM duplicates)
)
UPDATE user_profiles
SET device_id = device_id || '-old-' || id::text
WHERE id IN (
  SELECT id 
  FROM ranked_users 
  WHERE rn > 1
);

-- Now add NOT NULL and UNIQUE constraints
ALTER TABLE user_profiles 
  ALTER COLUMN device_id SET NOT NULL,
  ADD CONSTRAINT unique_device_id UNIQUE (device_id);