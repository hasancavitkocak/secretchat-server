/*
  # Create users and online status tables

  1. New Tables
    - `user_profiles`
      - `id` (uuid, primary key)
      - `nickname` (text)
      - `gender` (text)
      - `bio` (text)
      - `interests` (text[])
      - `is_premium` (boolean)
      - `premium_until` (timestamptz)
      - `created_at` (timestamptz)
      - `last_seen` (timestamptz)
      - `is_online` (boolean)

  2. Security
    - Enable RLS on `user_profiles` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nickname text NOT NULL,
  gender text,
  bio text,
  interests text[],
  is_premium boolean DEFAULT false,
  premium_until timestamptz,
  created_at timestamptz DEFAULT now(),
  last_seen timestamptz DEFAULT now(),
  is_online boolean DEFAULT false
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own profile
CREATE POLICY "Users can read own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Allow users to update their own profile
CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Allow users to read online users for matching
CREATE POLICY "Users can read online users"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (is_online = true);

-- Function to update last_seen and online status
CREATE OR REPLACE FUNCTION update_user_status()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_seen = now();
  NEW.is_online = true;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;