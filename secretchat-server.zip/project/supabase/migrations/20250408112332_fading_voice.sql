/*
  # Online Users and Matching System

  1. New Tables
    - `chat_matches`
      - `id` (uuid, primary key)
      - `user1_id` (uuid, references user_profiles)
      - `user2_id` (uuid, references user_profiles)
      - `status` (text: 'pending', 'active', 'ended')
      - `created_at` (timestamp)
      - `ended_at` (timestamp)

  2. Changes
    - Add `device_id` column to user_profiles
    - Add `reported_by` column to user_profiles for handling reports

  3. Security
    - Enable RLS on chat_matches table
    - Add policies for chat participants
*/

-- Add device_id to user_profiles
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'device_id'
  ) THEN 
    ALTER TABLE user_profiles ADD COLUMN device_id text;
  END IF;
END $$;

-- Add reported_by array to user_profiles
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'reported_by'
  ) THEN 
    ALTER TABLE user_profiles ADD COLUMN reported_by uuid[] DEFAULT '{}';
  END IF;
END $$;

-- Create chat_matches table
CREATE TABLE IF NOT EXISTS chat_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user1_id uuid REFERENCES user_profiles(id) NOT NULL,
  user2_id uuid REFERENCES user_profiles(id) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  CONSTRAINT valid_status CHECK (status IN ('pending', 'active', 'ended'))
);

-- Enable RLS
ALTER TABLE chat_matches ENABLE ROW LEVEL SECURITY;

-- Policies for chat_matches
CREATE POLICY "Users can see their own matches"
  ON chat_matches
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user1_id OR 
    auth.uid() = user2_id
  );

CREATE POLICY "Users can update their own matches"
  ON chat_matches
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = user1_id OR 
    auth.uid() = user2_id
  )
  WITH CHECK (
    auth.uid() = user1_id OR 
    auth.uid() = user2_id
  );

-- Function to find match
CREATE OR REPLACE FUNCTION find_match(
  p_user_id uuid,
  p_interests text[] DEFAULT NULL,
  p_gender text DEFAULT NULL
)
RETURNS TABLE (matched_user_id uuid) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT up.id
  FROM user_profiles up
  WHERE up.is_online = true
    AND up.id != p_user_id
    AND NOT EXISTS (
      SELECT 1 
      FROM chat_matches cm 
      WHERE (cm.user1_id = p_user_id AND cm.user2_id = up.id)
         OR (cm.user2_id = p_user_id AND cm.user1_id = up.id)
    )
    AND (p_gender IS NULL OR up.gender = p_gender)
    AND (
      p_interests IS NULL 
      OR up.interests && p_interests
    )
  ORDER BY up.last_seen DESC
  LIMIT 1;
END;
$$;