/*
  # Fix user profiles RLS policies

  1. Changes
    - Add policy to allow creation of new user profiles
    - Modify existing policies to handle unauthenticated users

  2. Security
    - Enable RLS on user_profiles table
    - Add policy for creating new profiles
    - Update existing policies to work with device_id
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read online users" ON user_profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON user_profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;

-- Create new policies
CREATE POLICY "Enable creating new profiles"
  ON user_profiles
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can read online users"
  ON user_profiles
  FOR SELECT
  TO public
  USING (is_online = true);

CREATE POLICY "Users can read own profile by device"
  ON user_profiles
  FOR SELECT
  TO public
  USING (device_id = current_setting('app.device_id', true));

CREATE POLICY "Users can update own profile by device"
  ON user_profiles
  FOR UPDATE
  TO public
  USING (device_id = current_setting('app.device_id', true))
  WITH CHECK (device_id = current_setting('app.device_id', true));