/*
  # Add preferred gender column to user profiles

  1. Changes
    - Add `preferred_gender` column to `user_profiles` table with default value 'any'
    - Make the column nullable to maintain compatibility with existing records
    
  2. Security
    - No changes to RLS policies needed as this column will be covered by existing policies
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' 
    AND column_name = 'preferred_gender'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN preferred_gender text DEFAULT 'any';
  END IF;
END $$;