import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Validate URL format
try {
  new URL(supabaseUrl);
} catch (e) {
  throw new Error('Invalid Supabase URL format');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  db: {
    schema: 'public'
  },
  auth: {
    persistSession: false,
    autoRefreshToken: true,
    detectSessionInUrl: false
  },
  global: {
    headers: {
      'Content-Type': 'application/json'
    }
  }
});

// Enhanced connectivity check using a more reliable method
const checkNetworkConnectivity = async (): Promise<boolean> => {
  try {
    // First check general internet connectivity
    const response = await fetch('https://www.google.com/favicon.ico', {
      mode: 'no-cors',
      cache: 'no-store'
    });
    
    if (!response.ok && response.type !== 'opaque') {
      console.warn('General internet connectivity check failed');
      return false;
    }

    // Then check Supabase connectivity with a lightweight query
    const { error } = await supabase
      .from('user_profiles')
      .select('id', { count: 'exact', head: true })
      .limit(1);
    
    if (error) {
      console.warn('Supabase connectivity check failed:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.warn('Network connectivity check failed:', error);
    return false;
  }
};

// Enhanced retry mechanism with exponential backoff
const retryOperation = async (operation: () => Promise<any>, maxRetries = 3) => {
  let lastError: Error | null = null;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const isConnected = await checkNetworkConnectivity();
      if (!isConnected) {
        console.warn(`No network connectivity (attempt ${i + 1}/${maxRetries})`);
        throw new Error('No network connectivity');
      }
      return await operation();
    } catch (error) {
      lastError = error as Error;
      console.error(`Operation failed (attempt ${i + 1}/${maxRetries}):`, error);
      
      if (i === maxRetries - 1) {
        throw new Error(`Operation failed after ${maxRetries} attempts. Last error: ${lastError.message}`);
      }
      
      // Exponential backoff with jitter
      const baseDelay = Math.min(1000 * Math.pow(2, i), 10000);
      const jitter = Math.random() * 1000;
      const delay = baseDelay + jitter;
      
      console.log(`Retrying in ${Math.round(delay/1000)} seconds...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
};

export const updateOnlineStatus = async (userId: string, isOnline: boolean) => {
  if (!userId) {
    console.warn('updateOnlineStatus called without userId');
    return;
  }

  const updateOperation = async () => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ 
          is_online: isOnline,
          last_seen: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) {
        console.error('Supabase error updating online status:', error);
        throw error;
      }
    } catch (error) {
      if (error instanceof Error) {
        console.error('Error updating online status:', {
          message: error.message,
          userId,
          isOnline,
          timestamp: new Date().toISOString()
        });
      }
      throw error;
    }
  };

  try {
    await retryOperation(updateOperation);
  } catch (error) {
    console.error('Failed to update online status after retries:', {
      userId,
      isOnline,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    });
  }
};

export const updateUserPreferences = async (userId: string, preferences: { interests?: string[], preferred_gender?: string }) => {
  if (!userId) return;

  try {
    const { error } = await supabase
      .from('user_profiles')
      .update(preferences)
      .eq('id', userId);

    if (error) {
      console.error('Error updating user preferences:', error);
      throw error;
    }
  } catch (error) {
    console.error('Unknown error updating user preferences:', error);
    throw error;
  }
};

export const findMatch = async (userId: string) => {
  if (!userId) return null;

  try {
    // First get current user's preferences
    const { data: currentUser } = await supabase
      .from('user_profiles')
      .select('interests, preferred_gender')
      .eq('id', userId)
      .single();

    if (!currentUser) return null;

    // Find potential matches
    let query = supabase
      .from('user_profiles')
      .select()
      .eq('is_online', true)
      .neq('id', userId)
      .not('reported_by', 'cs', `{${userId}}`);

    // Apply gender filter if specified
    if (currentUser.preferred_gender && currentUser.preferred_gender !== 'any') {
      query = query.eq('gender', currentUser.preferred_gender);
    }

    // Get potential matches
    const { data: potentialMatches, error: matchError } = await query;

    if (matchError) {
      console.error('Error finding matches:', matchError);
      return null;
    }

    if (!potentialMatches?.length) return null;

    // Filter by interests if specified
    let filteredMatches = potentialMatches;
    if (currentUser.interests && currentUser.interests.length > 0 && !currentUser.interests.includes('any')) {
      filteredMatches = potentialMatches.filter(match => 
        match.interests && 
        match.interests.some((interest: string) => currentUser.interests.includes(interest))
      );
    }

    // If no matches with similar interests, fall back to all potential matches
    const matchPool = filteredMatches.length > 0 ? filteredMatches : potentialMatches;
    const match = matchPool[Math.floor(Math.random() * matchPool.length)];

    // Create chat match
    const { data: chatMatch, error: chatError } = await supabase
      .from('chat_matches')
      .insert([{
        user1_id: userId,
        user2_id: match.id,
        status: 'active'
      }])
      .select()
      .single();

    if (chatError) {
      console.error('Error creating chat match:', chatError);
      return null;
    }

    return match;
  } catch (error) {
    console.error('Error in findMatch:', error);
    return null;
  }
};

export const createUserProfile = async (deviceId: string) => {
  try {
    // First try to get existing user
    const { data: existingUser, error: selectError } = await supabase
      .from('user_profiles')
      .select()
      .eq('device_id', deviceId)
      .maybeSingle();

    if (selectError) {
      console.error('Error checking for existing user:', selectError);
      throw selectError;
    }

    if (existingUser) {
      return existingUser;
    }

    // If no existing user, create a new one
    const { data: newUser, error: insertError } = await supabase
      .from('user_profiles')
      .insert([{
        device_id: deviceId,
        nickname: `User${Math.floor(Math.random() * 10000)}`,
        is_online: true,
        last_seen: new Date().toISOString(),
        interests: ['any'],
        gender: null,
        bio: null,
        is_premium: false
      }])
      .select()
      .single();

    if (insertError) {
      console.error('Error creating new user:', insertError);
      throw insertError;
    }

    return newUser;
  } catch (error) {
    console.error('Error in createUserProfile:', error);
    throw error;
  }
};

export const reportUser = async (reporterId: string, reportedId: string) => {
  try {
    const { error } = await supabase
      .from('user_profiles')
      .update({
        reported_by: supabase.sql`array_append(reported_by, ${reporterId}::uuid)`
      })
      .eq('id', reportedId);

    if (error) throw error;
  } catch (error) {
    console.error('Error reporting user:', error);
  }
};