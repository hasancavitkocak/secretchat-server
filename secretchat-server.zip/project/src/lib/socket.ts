import { io } from 'socket.io-client';

const SOCKET_URL = import.meta.env.PROD 
  ? 'https://your-render-app.onrender.com' // This will need to be updated with your actual Render.com URL
  : `${window.location.protocol}//${window.location.hostname}:3000`;

export const socket = io(SOCKET_URL, {
  autoConnect: false,
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
  timeout: 20000,
  transports: ['websocket', 'polling'],
  path: '/socket.io/',
});

let matchTimeout: NodeJS.Timeout | null = null;

socket.on('connect_error', (error) => {
  console.error('Socket connection error:', error);
  setTimeout(() => {
    if (!socket.connected) {
      socket.connect();
    }
  }, 2000);
});

socket.on('connect_timeout', () => {
  console.error('Socket connection timeout');
  setTimeout(() => {
    if (!socket.connected) {
      socket.connect();
    }
  }, 2000);
});

socket.on('error', (error) => {
  console.error('Socket error:', error);
});

socket.on('connect', () => {
  console.log('Socket connected successfully');
});

socket.on('disconnect', (reason) => {
  console.log('Socket disconnected:', reason);
  if (reason !== 'io client disconnect') {
    setTimeout(() => {
      if (!socket.connected) {
        socket.connect();
      }
    }, 2000);
  }
});

socket.on('ping', () => {
  socket.emit('pong');
});

export const connectSocket = (userId: string) => {
  if (!socket.connected) {
    console.log('Connecting socket...');
    socket.connect();
    socket.emit('register', userId);
  }
};

export const disconnectSocket = () => {
  if (socket.connected) {
    socket.disconnect();
  }
};

export const findMatch = (userId: string, preferences: any) => {
  if (matchTimeout) {
    clearTimeout(matchTimeout);
    matchTimeout = null;
  }

  if (!socket.connected) {
    console.warn('Socket not connected. Attempting to reconnect...');
    socket.connect();
    socket.once('connect', () => {
      socket.emit('find_match', { userId, preferences });
    });
  } else {
    socket.emit('find_match', { userId, preferences });
  }

  matchTimeout = setTimeout(() => {
    if (socket.connected) {
      console.log('Retrying match with broader preferences...');
      socket.emit('find_match', { 
        userId, 
        preferences: {
          ...preferences,
          preferred_gender: 'any',
          interests: ['any']
        }
      });
    }
  }, 45000);
};

export const cancelSearch = (userId: string) => {
  if (matchTimeout) {
    clearTimeout(matchTimeout);
    matchTimeout = null;
  }

  if (socket.connected) {
    socket.emit('cancel_search', userId);
  }
};

export const sendMessage = (to: string, message: any) => {
  if (!socket.connected) {
    console.warn('Socket not connected. Attempting to reconnect...');
    socket.connect();
    socket.once('connect', () => {
      socket.emit('send_message', { to, message });
    });
  } else {
    socket.emit('send_message', { to, message });
  }
};