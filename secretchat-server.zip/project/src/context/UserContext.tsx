import React, { createContext, useContext, useState, useEffect } from 'react';
import { getDeviceId } from '../lib/deviceId';
import { createUserProfile, updateOnlineStatus } from '../lib/supabase';
import { connectSocket, disconnectSocket } from '../lib/socket';

interface UserContextType {
  userId: string | null;
  isLoading: boolean;
  error: string | null;
}

const UserContext = createContext<UserContextType>({
  userId: null,
  isLoading: true,
  error: null
});

export const useUser = () => useContext(UserContext);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  let retryCount = 0;
  const maxRetries = 3;

  useEffect(() => {
    let mounted = true;

    const initializeUser = async () => {
      try {
        const deviceId = getDeviceId();
        
        const createProfileWithRetry = async () => {
          try {
            const userProfile = await createUserProfile(deviceId);
            if (!userProfile) {
              throw new Error('Failed to create or retrieve user profile');
            }
            return userProfile;
          } catch (error) {
            if (retryCount < maxRetries) {
              retryCount++;
              const delay = Math.min(1000 * Math.pow(2, retryCount), 5000);
              await new Promise(resolve => setTimeout(resolve, delay));
              return createProfileWithRetry();
            }
            throw error;
          }
        };

        const userProfile = await createProfileWithRetry();
        
        if (!mounted) return;

        if (userProfile?.id) {
          setUserId(userProfile.id);
          connectSocket(userProfile.id);
          
          const handleVisibilityChange = () => {
            if (document.visibilityState === 'visible') {
              updateOnlineStatus(userProfile.id, true);
            } else {
              updateOnlineStatus(userProfile.id, false);
            }
          };
          
          const handleBeforeUnload = () => {
            updateOnlineStatus(userProfile.id, false);
            disconnectSocket();
          };
          
          document.addEventListener('visibilitychange', handleVisibilityChange);
          window.addEventListener('beforeunload', handleBeforeUnload);
          
          return () => {
            document.removeEventListener('visibilitychange', handleVisibilityChange);
            window.removeEventListener('beforeunload', handleBeforeUnload);
            if (userProfile.id) {
              updateOnlineStatus(userProfile.id, false);
              disconnectSocket();
            }
          };
        } else {
          setError('Failed to create or retrieve user profile');
        }
      } catch (error) {
        console.error('Error initializing user:', error);
        if (mounted) {
          setError(error instanceof Error ? error.message : 'Failed to initialize user');
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    initializeUser();

    return () => {
      mounted = false;
    };
  }, []);

  return (
    <UserContext.Provider value={{ userId, isLoading, error }}>
      {children}
    </UserContext.Provider>
  );
}