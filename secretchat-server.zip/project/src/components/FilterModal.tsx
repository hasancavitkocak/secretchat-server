import React, { useState } from 'react';
import { X, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFilterChange: (filters: string[]) => void;
}

export default function FilterModal({ isOpen, onClose, onFilterChange }: FilterModalProps) {
  const navigate = useNavigate();
  const [selectedGender, setSelectedGender] = useState<string>('any');
  const [selectedInterests, setSelectedInterests] = useState<string[]>(['any']);

  const interests = [
    'any', 'Gaming', 'Music', 'Movies', 'Sports', 'Travel',
    'Food', 'Art', 'Technology', 'Books', 'Fitness'
  ];

  const handleGenderSelect = (gender: string) => {
    if (gender === 'male' || gender === 'female') {
      navigate('/premium');
    } else {
      setSelectedGender(gender);
    }
  };

  const toggleInterest = (interest: string) => {
    if (interest === 'any') {
      setSelectedInterests(['any']);
    } else {
      setSelectedInterests(prev => {
        if (prev.includes('any')) {
          return [interest];
        }
        return prev.includes(interest)
          ? prev.filter(i => i !== interest)
          : [...prev, interest];
      });
    }
  };

  const applyFilters = () => {
    const filters = [
      selectedGender,
      ...(selectedInterests.includes('any') ? ['any'] : selectedInterests)
    ];
    onFilterChange(filters);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Filters</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Gender</h3>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => handleGenderSelect('male')}
              className="py-2 px-4 rounded-lg border border-gray-300 hover:border-blue-500 flex items-center justify-center gap-2"
            >
              <span>Male</span>
              <DollarSign className="w-4 h-4 text-yellow-500" />
            </button>
            <button
              onClick={() => handleGenderSelect('female')}
              className="py-2 px-4 rounded-lg border border-gray-300 hover:border-blue-500 flex items-center justify-center gap-2"
            >
              <span>Female</span>
              <DollarSign className="w-4 h-4 text-yellow-500" />
            </button>
            <button
              onClick={() => handleGenderSelect('any')}
              className={`py-2 px-4 rounded-lg border ${
                selectedGender === 'any'
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white border-transparent'
                  : 'border-gray-300 hover:border-blue-500'
              }`}
            >
              Any
            </button>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Interests</h3>
          <div className="grid grid-cols-2 gap-2">
            {interests.map(interest => (
              <button
                key={interest}
                onClick={() => toggleInterest(interest)}
                className={`py-2 px-4 rounded-lg border ${
                  selectedInterests.includes(interest)
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white border-transparent'
                    : 'border-gray-300 hover:border-blue-500'
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={applyFilters}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 rounded-lg hover:opacity-90 transition-all duration-300"
        >
          Apply Filters
        </button>
      </div>
    </div>
  );
}