import React, { useState } from 'react';
import { Crown, Users, Clock, Headphones, ArrowLeft, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PremiumScreen() {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);

  const features = [
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Partner Gender Selection',
      description: 'Choose the gender of your chat partners'
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: 'Priority Matching',
      description: 'Get matched faster with other users'
    },
    {
      icon: <Headphones className="w-6 h-6" />,
      title: 'Priority Support',
      description: '24/7 premium customer support'
    }
  ];

  const plans = [
    {
      duration: 'Weekly',
      price: '$4.99',
      featured: false
    },
    {
      duration: 'Monthly',
      price: '$14.99',
      featured: true
    },
    {
      duration: 'Yearly',
      price: '$99.99',
      featured: false,
      savings: 'Save 45%'
    }
  ];

  const handleSubscribe = async () => {
    if (selectedPlan === null) return;
    
    try {
      // Here we'll implement the subscription logic with Supabase
      console.log('Subscribing to plan:', plans[selectedPlan]);
    } catch (error) {
      console.error('Error subscribing:', error);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto pb-20">
      <div className="flex items-center mb-6">
        <button
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800 ml-2">Premium Features</h1>
      </div>

      <div className="text-center mb-8">
        <Crown className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Upgrade to Premium</h2>
        <p className="text-gray-600">Unlock all premium features and enhance your experience</p>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl shadow-md p-6 mb-8">
        <h2 className="text-lg font-semibold mb-4">Premium Features</h2>
        <div className="space-y-4">
          {features.map((feature, index) => (
            <div key={index} className="flex items-start gap-4">
              <div className="text-blue-500">{feature.icon}</div>
              <div>
                <h3 className="font-medium text-gray-800">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-8">
        {plans.map((plan, index) => (
          <div
            key={index}
            onClick={() => setSelectedPlan(index)}
            className={`bg-white rounded-xl p-4 text-center cursor-pointer transition-all duration-300 ${
              selectedPlan === index
                ? 'ring-2 ring-blue-500 shadow-lg scale-105'
                : 'border shadow hover:shadow-md'
            }`}
          >
            <p className="text-gray-600 mb-2">{plan.duration}</p>
            <p className="text-xl font-bold text-gray-800">{plan.price}</p>
            {plan.savings && (
              <p className="text-green-500 text-sm mt-1">{plan.savings}</p>
            )}
            {selectedPlan === index && (
              <div className="mt-2 text-blue-500">
                <Check className="w-5 h-5 mx-auto" />
              </div>
            )}
          </div>
        ))}
      </div>

      <button
        onClick={handleSubscribe}
        disabled={selectedPlan === null}
        className={`w-full py-4 rounded-xl text-white font-medium shadow-md transition-all duration-300 ${
          selectedPlan !== null
            ? 'bg-gradient-to-r from-blue-500 to-purple-500 hover:opacity-90'
            : 'bg-gray-300 cursor-not-allowed'
        }`}
      >
        Subscribe Now
      </button>
    </div>
  );
}