import React, { useState, useEffect } from 'react';
import { User, Heart, Camera } from 'lucide-react';

export default function SettingsScreen() {
  const [profile, setProfile] = useState({
    nickname: '',
    gender: '',
    bio: '',
    interests: [] as string[],
    notifications: true
  });

  useEffect(() => {
    // Generate random nickname on component mount
    const randomNickname = `User${Math.floor(Math.random() * 10000)}`;
    setProfile(prev => ({ ...prev, nickname: randomNickname }));
  }, []);

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Profile Settings</h1>

      <div className="space-y-6">
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              <User className="w-12 h-12 text-gray-400" />
            </div>
            <button className="absolute bottom-0 right-0 bg-blue-500 text-white p-2 rounded-full">
              <Camera className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Nickname
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 border rounded-lg bg-gray-100"
            value={profile.nickname}
            disabled
          />
          <p className="text-sm text-gray-500 mt-1">Automatically generated nickname</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Gender
          </label>
          <div className="grid grid-cols-3 gap-3">
            {['male', 'female', 'other'].map(gender => (
              <button
                key={gender}
                onClick={() => setProfile(prev => ({ ...prev, gender }))}
                className={`py-2 px-4 rounded-lg border ${
                  profile.gender === gender
                    ? 'bg-blue-500 text-white border-blue-500'
                    : 'border-gray-300 hover:border-blue-500'
                }`}
              >
                {gender.charAt(0).toUpperCase() + gender.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            About Me
          </label>
          <textarea
            className="w-full px-4 py-2 border rounded-lg"
            rows={4}
            placeholder="Tell us about yourself..."
            value={profile.bio}
            onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
          />
        </div>

        <div className="flex items-center justify-between py-4 border-t">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-gray-600" />
            <span className="text-gray-700">Interests</span>
          </div>
          <button className="text-blue-500">Edit</button>
        </div>
      </div>
    </div>
  );
}