import React from 'react';
import { MessageCircle, Flag, X, Image } from 'lucide-react';

export default function RequestsScreen() {
  const requests = [
    {
      id: 1,
      nickname: 'Anonymous123',
      message: 'Hey! Would you like to chat?',
      time: '5 min ago'
    },
    // Add more mock data as needed
  ];

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Chat Requests</h1>
      
      <div className="space-y-4">
        {requests.map(request => (
          <div key={request.id} className="bg-white rounded-lg shadow p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-medium text-gray-800">{request.nickname}</h3>
                <p className="text-sm text-gray-500">{request.time}</p>
              </div>
              <div className="flex gap-2">
                <button className="text-green-500 hover:text-green-600">
                  <MessageCircle className="w-5 h-5" />
                </button>
                <button className="text-red-500 hover:text-red-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <p className="text-gray-600">{request.message}</p>
          </div>
        ))}
      </div>

      {/* Chat Interface */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 max-w-md mx-auto">
        <div className="flex gap-2">
          <button className="p-2 text-gray-500 hover:text-gray-700">
            <Image className="w-6 h-6" />
          </button>
          <input
            type="text"
            placeholder="Type a message..."
            className="flex-1 border rounded-full px-4 py-2"
          />
          <button className="p-2 text-red-500 hover:text-red-700">
            <Flag className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}