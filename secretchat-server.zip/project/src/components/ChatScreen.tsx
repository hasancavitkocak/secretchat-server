import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Image, Send, MoreVertical, Flag, X, Users } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase, reportUser } from '../lib/supabase';
import { useUser } from '../context/UserContext';
import { socket, sendMessage } from '../lib/socket';

interface Message {
  id: number;
  text: string;
  sent: boolean;
  timestamp: Date;
  image?: string;
}

export default function ChatScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const { userId } = useUser();
  const partnerId = location.state?.partnerId;
  
  const [message, setMessage] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [partnerProfile, setPartnerProfile] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    if (!partnerId) {
      navigate('/');
      return;
    }

    const fetchPartnerProfile = async () => {
      const { data } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', partnerId)
        .single();
      
      if (data) {
        setPartnerProfile(data);
      }
    };

    fetchPartnerProfile();

    // Socket.IO message handling
    const handleReceiveMessage = (message: any) => {
      setMessages(prev => [...prev, {
        id: prev.length + 1,
        text: message.text,
        sent: false,
        timestamp: new Date(),
        image: message.image
      }]);
    };

    socket.on('receive_message', handleReceiveMessage);

    return () => {
      socket.off('receive_message', handleReceiveMessage);
    };
  }, [partnerId, navigate]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!message.trim() || !partnerId) return;

    const newMessage = {
      text: message,
      timestamp: new Date()
    };

    sendMessage(partnerId, newMessage);

    setMessages(prev => [...prev, {
      id: prev.length + 1,
      text: message,
      sent: true,
      timestamp: new Date()
    }]);
    
    setMessage('');
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && partnerId) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageMessage = {
          text: '',
          image: e.target?.result as string,
          timestamp: new Date()
        };

        sendMessage(partnerId, imageMessage);

        setMessages(prev => [...prev, {
          id: prev.length + 1,
          text: '',
          sent: true,
          timestamp: new Date(),
          image: e.target?.result as string
        }]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleReport = async () => {
    if (!userId || !partnerId) return;
    
    await reportUser(userId, partnerId);
    setShowReportDialog(false);
    navigate('/');
  };

  const handleEndChat = async () => {
    if (userId && partnerId) {
      await supabase
        .from('chat_matches')
        .update({ status: 'ended', ended_at: new Date().toISOString() })
        .or(`user1_id.eq.${userId},user2_id.eq.${userId}`);
    }
    navigate('/');
  };

  if (!partnerId || !partnerProfile) {
    return null;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <div className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
        <div className="max-w-md mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/')}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <h2 className="font-semibold text-gray-800">{partnerProfile.nickname}</h2>
                <p className="text-sm text-green-500">{partnerProfile.is_online ? 'Online' : 'Offline'}</p>
              </div>
            </div>
            <button 
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 hover:bg-gray-100 rounded-full relative"
            >
              <MoreVertical className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          {showMenu && (
            <div className="absolute right-4 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-10">
              <button
                onClick={() => navigate('/')}
                className="w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-100 flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                New Partner
              </button>
              <button
                onClick={() => setShowReportDialog(true)}
                className="w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100 flex items-center gap-2"
              >
                <Flag className="w-4 h-4" />
                Report User
              </button>
              <button
                onClick={handleEndChat}
                className="w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-100 flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                End Chat
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 mt-16 mb-20">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sent ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[75%] rounded-2xl px-4 py-2 ${
                msg.sent
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                  : 'bg-white text-gray-800 shadow-sm'
              }`}
            >
              {msg.image ? (
                <img src={msg.image} alt="Shared" className="rounded-lg max-w-full" />
              ) : (
                <p>{msg.text}</p>
              )}
              <p
                className={`text-xs mt-1 ${
                  msg.sent ? 'text-blue-100' : 'text-gray-500'
                }`}
              >
                {msg.timestamp.toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="bg-white border-t p-4 fixed bottom-0 left-0 right-0">
        <div className="max-w-md mx-auto flex items-end gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-500 hover:text-gray-700"
          >
            <Image className="w-6 h-6" />
          </button>
          <div className="flex-1 relative">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="w-full border rounded-2xl px-4 py-2 max-h-32 focus:outline-none focus:border-blue-500 resize-none"
              rows={1}
            />
          </div>
          <button
            onClick={handleSend}
            disabled={!message.trim()}
            className={`p-2 rounded-full ${
              message.trim()
                ? 'text-blue-500 hover:text-blue-700'
                : 'text-gray-400'
            }`}
          >
            <Send className="w-6 h-6" />
          </button>
        </div>
      </div>

      {showReportDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-sm">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Report User</h3>
            <p className="text-gray-600 mb-6">Are you sure you want to report this user? This will end the chat and block them from matching with you again.</p>
            <div className="flex gap-3">
              <button
                onClick={handleReport}
                className="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600"
              >
                Report
              </button>
              <button
                onClick={() => setShowReportDialog(false)}
                className="flex-1 bg-gray-100 text-gray-800 py-2 rounded-lg hover:bg-gray-200"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}