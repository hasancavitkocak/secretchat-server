import React from 'react';
import { Search, Users, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export default function Navigation() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
      <div className="max-w-md mx-auto px-4">
        <div className="flex justify-around py-3">
          <Link
            to="/"
            className={location.pathname === '/' ? 'text-blue-500' : 'text-gray-500'}
          >
            <Search className="w-6 h-6" />
          </Link>
          <Link
            to="/requests"
            className={location.pathname === '/requests' ? 'text-blue-500' : 'text-gray-500'}
          >
            <Users className="w-6 h-6" />
          </Link>
          <Link
            to="/settings"
            className={location.pathname === '/settings' ? 'text-blue-500' : 'text-gray-500'}
          >
            <Settings className="w-6 h-6" />
          </Link>
        </div>
      </div>
    </nav>
  );
}