import React, { useState, useEffect } from 'react';
import { Search, Filter, Users } from 'lucide-react';
import FilterModal from './FilterModal';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { socket, findMatch, cancelSearch } from '../lib/socket';

export default function SearchScreen() {
  const [isSearching, setIsSearching] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>(['any', 'any']);
  const [showMatchDialog, setShowMatchDialog] = useState(false);
  const [matchedProfile, setMatchedProfile] = useState<any>(null);
  const navigate = useNavigate();
  const { userId, isLoading } = useUser();

  useEffect(() => {
    if (!socket.connected) return;

    const handleMatchFound = (data: { partnerId: string }) => {
      setIsSearching(false);
      setMatchedProfile({ id: data.partnerId });
      setShowMatchDialog(true);
    };

    socket.on('match_found', handleMatchFound);

    return () => {
      socket.off('match_found', handleMatchFound);
    };
  }, [socket.connected]);

  const handleMatch = () => {
    if (!userId || isLoading) return;
    
    setIsSearching(true);
    findMatch(userId, {
      interests: activeFilters.filter(f => !['male', 'female', 'any'].includes(f)),
      preferred_gender: activeFilters.find(f => ['male', 'female', 'any'].includes(f)) || 'any'
    });
  };

  const handleCancelSearch = () => {
    if (!userId) return;
    cancelSearch(userId);
    setIsSearching(false);
  };

  const handleAcceptMatch = () => {
    setShowMatchDialog(false);
    navigate('/chat', { state: { partnerId: matchedProfile.id } });
  };

  const handleNewPartner = () => {
    setShowMatchDialog(false);
    setMatchedProfile(null);
    handleMatch();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-md mx-auto min-h-screen pb-24">
      <div className="text-center pt-8 mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3">Secret Chat</h1>
        <p className="text-gray-600">Connect with random people around the world</p>
      </div>

      <div className="space-y-6">
        <button
          onClick={() => setShowFilter(true)}
          className="w-full bg-white rounded-xl p-4 shadow-sm flex items-center justify-between hover:shadow-md transition-shadow duration-300"
        >
          <div className="flex items-center gap-3">
            <Filter className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700 font-medium">Search Preferences</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">
              {activeFilters[0] === 'any' ? 'All genders' : activeFilters[0]}
            </span>
            <span className="text-gray-300">•</span>
            <span className="text-sm text-gray-500">
              {activeFilters[1] === 'any' ? 'Any interests' : `${activeFilters.length - 1} interests`}
            </span>
          </div>
        </button>

        <button
          onClick={handleMatch}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white rounded-2xl p-8 shadow-lg transform transition-all duration-300 hover:scale-[1.02] relative overflow-hidden"
        >
          <div className="flex flex-col items-center gap-4">
            <Search className="w-12 h-12" />
            <div>
              <h3 className="text-xl font-semibold mb-1">Find Chat Partner</h3>
              <p className="text-sm text-blue-100">Click to start searching</p>
            </div>
          </div>
        </button>

        {(activeFilters[0] !== 'any' || activeFilters[1] !== 'any') && (
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Active Filters</h3>
            <div className="flex flex-wrap gap-2">
              {activeFilters.map((filter, index) => (
                filter !== 'any' && (
                  <span
                    key={index}
                    className="px-3 py-1 bg-gradient-to-r from-blue-50 to-purple-50 text-blue-800 rounded-full text-sm font-medium border border-blue-100"
                  >
                    {filter}
                  </span>
                )
              ))}
            </div>
          </div>
        )}
      </div>

      {isSearching && (
        <div className="text-center fixed inset-0 bg-white bg-opacity-90 flex flex-col items-center justify-center z-50">
          <div className="relative mb-8">
            <div className="relative bg-gradient-to-r from-blue-500 to-purple-500 rounded-full p-4 inline-flex">
              <Search className="w-8 h-8 text-white animate-pulse" />
            </div>
          </div>
          <p className="text-xl font-medium text-gray-800 mb-2">
            Searching for partner...
          </p>
          <p className="text-gray-500 mb-6">Looking for someone with similar interests</p>
          <button
            onClick={handleCancelSearch}
            className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full transition-all duration-300 shadow-md"
          >
            Cancel
          </button>
        </div>
      )}

      {showMatchDialog && matchedProfile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Match Found!</h3>
              <p className="text-gray-600 mb-4">Someone wants to chat with you</p>
            </div>
            <div className="space-y-3">
              <button
                onClick={handleAcceptMatch}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 rounded-xl transition-all duration-300"
              >
                Start Chat
              </button>
              <button
                onClick={handleNewPartner}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 rounded-xl transition-all duration-300"
              >
                Find New Partner
              </button>
              <button
                onClick={() => {
                  setShowMatchDialog(false);
                  setMatchedProfile(null);
                }}
                className="w-full text-gray-500 hover:text-gray-700 py-2"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <FilterModal
        isOpen={showFilter}
        onClose={() => setShowFilter(false)}
        onFilterChange={setActiveFilters}
      />
    </div>
  );
}