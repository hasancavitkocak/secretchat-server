import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.static('dist'));
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../../dist/index.html'));
});

const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: [
      "http://localhost:5173",
      "https://localhost:5173",
      "http://192.168.1.103:5173",
      "https://192.168.1.103:5173",
      "https://enchanting-melba-359909.netlify.app"
    ],
    methods: ["GET", "POST"],
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"]
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000,
  path: '/socket.io/',
  connectTimeout: 45000,
  maxHttpBufferSize: 1e6
});

// Enhanced user management with preferences
const onlineUsers = new Map(); // userId -> socketId
const userPreferences = new Map(); // userId -> preferences
const waitingUsers = new Map(); // userId -> { preferences, timestamp }

// Helper function to check if users match based on preferences
const usersMatch = (user1Prefs, user2Prefs) => {
  // Gender preference matching
  const genderMatches = (pref1, pref2) => {
    if (pref1.preferred_gender === 'any' || pref2.preferred_gender === 'any') return true;
    return pref1.preferred_gender === pref2.gender && pref2.preferred_gender === pref1.gender;
  };

  // Interest matching
  const interestsMatch = (interests1, interests2) => {
    if (interests1.includes('any') || interests2.includes('any')) return true;
    return interests1.some(interest => interests2.includes(interest));
  };

  return genderMatches(user1Prefs, user2Prefs) && 
         interestsMatch(user1Prefs.interests, user2Prefs.interests);
};

// Find best match for a user
const findBestMatch = (userId, userPrefs) => {
  let bestMatch = null;
  let oldestWaitingTime = 0;

  for (const [waitingUserId, waitingData] of waitingUsers.entries()) {
    if (waitingUserId === userId) continue;

    const waitingTime = Date.now() - waitingData.timestamp;
    const prefsMatch = usersMatch(userPrefs, waitingData.preferences);

    // Match if preferences match or if waiting time is too long (fallback matching)
    if (prefsMatch || waitingTime > 30000) { // 30 seconds fallback
      if (!bestMatch || waitingTime > oldestWaitingTime) {
        bestMatch = waitingUserId;
        oldestWaitingTime = waitingTime;
      }
    }
  }

  return bestMatch;
};

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  let userId = null;

  const pingInterval = setInterval(() => {
    socket.emit('ping');
  }, 25000);

  socket.on('pong', () => {
    console.log('Received pong from:', socket.id);
  });

  socket.on('register', (newUserId) => {
    userId = newUserId;
    onlineUsers.set(userId, socket.id);
    console.log('User registered:', userId);
    console.log('Online users:', Array.from(onlineUsers.keys()));
  });

  socket.on('find_match', (userData) => {
    const { userId, preferences } = userData;
    console.log('Finding match for user:', userId, 'with preferences:', preferences);

    if (waitingUsers.has(userId)) {
      console.log('User already in waiting list:', userId);
      return;
    }

    // Store user preferences
    userPreferences.set(userId, preferences);
    
    // Add to waiting list with timestamp
    waitingUsers.set(userId, {
      preferences,
      timestamp: Date.now()
    });

    // Try to find a match
    const matchedUserId = findBestMatch(userId, preferences);

    if (matchedUserId) {
      console.log('Match found:', userId, 'with', matchedUserId);
      
      // Remove both users from waiting list
      waitingUsers.delete(userId);
      waitingUsers.delete(matchedUserId);

      // Get socket IDs
      const userSocketId = onlineUsers.get(userId);
      const matchSocketId = onlineUsers.get(matchedUserId);

      if (userSocketId && matchSocketId) {
        // Notify both users
        io.to(userSocketId).emit('match_found', { 
          partnerId: matchedUserId,
          preferences: userPreferences.get(matchedUserId)
        });
        io.to(matchSocketId).emit('match_found', { 
          partnerId: userId,
          preferences: preferences
        });

        // Clean up preferences
        userPreferences.delete(userId);
        userPreferences.delete(matchedUserId);
      }
    } else {
      // Notify user they're in queue
      socket.emit('waiting_for_match');

      // Set timeout for matching
      setTimeout(() => {
        if (waitingUsers.has(userId)) {
          // If still waiting after 30 seconds, try matching with anyone
          const anyMatch = Array.from(waitingUsers.keys())
            .find(id => id !== userId);

          if (anyMatch) {
            const userSocketId = onlineUsers.get(userId);
            const matchSocketId = onlineUsers.get(anyMatch);

            if (userSocketId && matchSocketId) {
              waitingUsers.delete(userId);
              waitingUsers.delete(anyMatch);

              io.to(userSocketId).emit('match_found', { 
                partnerId: anyMatch,
                preferences: userPreferences.get(anyMatch)
              });
              io.to(matchSocketId).emit('match_found', { 
                partnerId: userId,
                preferences: preferences
              });

              userPreferences.delete(userId);
              userPreferences.delete(anyMatch);
            }
          }
        }
      }, 30000);
    }
  });

  socket.on('cancel_search', (userId) => {
    console.log('Search cancelled by user:', userId);
    waitingUsers.delete(userId);
    userPreferences.delete(userId);
  });

  socket.on('send_message', (data, callback) => {
    const { to, message } = data;
    const recipientSocket = onlineUsers.get(to);
    if (recipientSocket) {
      console.log('Sending message to:', to);
      io.to(recipientSocket).emit('receive_message', message);
      if (callback) callback({ delivered: true });
    } else {
      console.log('Recipient not found:', to);
      if (callback) callback({ delivered: false, error: 'Recipient offline' });
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    clearInterval(pingInterval);
    
    if (userId) {
      onlineUsers.delete(userId);
      waitingUsers.delete(userId);
      userPreferences.delete(userId);
      console.log('User removed from lists:', userId);
    }
  });
});

httpServer.on('error', (error) => {
  console.error('Server error:', error);
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Socket.IO server running on port ${PORT}`);
});