import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SearchScreen from './components/SearchScreen';
import RequestsScreen from './components/RequestsScreen';
import SettingsScreen from './components/SettingsScreen';
import PremiumScreen from './components/PremiumScreen';
import ChatScreen from './components/ChatScreen';
import Navigation from './components/Navigation';
import { UserProvider } from './context/UserContext';

function App() {
  return (
    <UserProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<SearchScreen />} />
            <Route path="/requests" element={<RequestsScreen />} />
            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="/premium" element={<PremiumScreen />} />
            <Route path="/chat" element={<ChatScreen />} />
          </Routes>
          <Navigation />
        </div>
      </Router>
    </UserProvider>
  );
}

export default App;